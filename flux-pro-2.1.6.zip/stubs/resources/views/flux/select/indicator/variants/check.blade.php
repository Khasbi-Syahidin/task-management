
<flux:icon variant="mini" icon="check" class="hidden [ui-option[data-selected]_&]:block" />
