
<div {{ $attributes->class('[:where(&)]:relative') }}>
    {{ $slot }}
</div>